﻿/*
 * THIBAULT LAZERT P1003011
 * UE ISI Polytech'Lyon
 * semestre automne 2012
 * 
 * Application gestion commerciale
 */
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using Metier;
using Utilitaires;

namespace Commercial.Presentation
{
    public partial class FDetailsCde : Form
    {
        
        /// <summary>
        /// Initialisation
        /// </summary>
        public FDetailsCde()
        {
            InitializeComponent();
           
        }

        

       
    }
}
